function showSection(section) {
    document.querySelectorAll('.section').forEach(s => s.classList.add('hidden'));
    document.getElementById(section).classList.remove('hidden');

    if(section === 'karyawan') loadJabatanToSelect();
    if(section === 'jabatan') loadJabatanTable();
    if(section === 'validasi') loadValidasiTable();
}

function logout() {
    alert('Logout berhasil!');
    window.location.href = 'login.html';
}

// ----- Jabatan -----
async function tambahJabatan() {
    let nama = document.getElementById('nama_jabatan').value;
    let gaji = document.getElementById('gaji_pokok').value;
    let tunjangan = document.getElementById('tunjangan').value;

    if(!nama || !gaji || !tunjangan) { alert('Semua field wajib diisi!'); return; }

    await eel.tambah_jabatan(nama, gaji, tunjangan)();
    loadJabatanTable();
    loadJabatanToSelect();
}

async function loadJabatanTable() {
    let data = await eel.get_all_jabatan()();
    let tbody = document.getElementById('tabelJabatan');
    tbody.innerHTML = '';
    data.forEach(j => {
        tbody.innerHTML += `<tr>
            <td class="border p-2">${j.id}</td>
            <td class="border p-2">${j.nama_jabatan}</td>
            <td class="border p-2">${j.gaji_pokok}</td>
            <td class="border p-2">${j.tunjangan}</td>
        </tr>`;
    });
}

async function loadJabatanToSelect() {
    let data = await eel.get_all_jabatan()();
    let select = document.getElementById('selectJabatan');
    select.innerHTML = '';
    data.forEach(j => {
        select.innerHTML += `<option value="${j.id}">${j.nama_jabatan}</option>`;
    });
}

// ----- Karyawan -----
async function tambahKaryawan() {
    let nama = document.getElementById('nama_karyawan').value;
    let nohp = document.getElementById('no_hp').value;
    let alamat = document.getElementById('alamat').value;
    let jabatan = document.getElementById('selectJabatan').value;
    let tgl = document.getElementById('tanggal_masuk').value;
    let username = document.getElementById('username_karyawan').value;
    let password = document.getElementById('password_karyawan').value;

    if(!nama || !jabatan || !username || !password) { alert('Nama, Jabatan, Username, Password wajib diisi!'); return; }

    await eel.tambah_karyawan(nama, nohp, alamat, jabatan, tgl, username, password)();
    loadKaryawanTable();
}

async function loadKaryawanTable() {
    let data = await eel.get_all_karyawan()();
    let tbody = document.getElementById('tabelKaryawan');
    tbody.innerHTML = '';
    data.forEach(k => {
        tbody.innerHTML += `<tr>
            <td class="border p-2">${k.id}</td>
            <td class="border p-2">${k.nama_lengkap}</td>
            <td class="border p-2">${k.no_hp}</td>
            <td class="border p-2">${k.alamat}</td>
            <td class="border p-2">${k.nama_jabatan}</td>
            <td class="border p-2">${k.tanggal_masuk}</td>
            <td class="border p-2">${k.username}</td>
        </tr>`;
    });
}

// ----- Validasi -----
async function loadValidasiTable() {
    let data = await eel.get_karyawan_belum_validasi()();
    let tbody = document.getElementById('tabelValidasi');
    tbody.innerHTML = '';
    data.forEach(k => {
        tbody.innerHTML += `<tr>
            <td class="border p-2">${k.id}</td>
            <td class="border p-2">${k.nama_lengkap}</td>
            <td class="border p-2">${k.username}</td>
            <td class="border p-2"><button class="bg-green-500 text-white px-3 py-1 rounded" onclick="validasiKaryawan(${k.id})">Validasi</button></td>
        </tr>`;
    });
}

async function validasiKaryawan(id) {
    await eel.validasi_karyawan(id)();
    loadValidasiTable();
}
