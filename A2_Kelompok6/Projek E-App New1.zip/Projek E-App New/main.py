import eel
from db import DB
import hashlib
import pdfkit
import datetime

# ======== INIT ========
eel.init('web')
db = DB()

# ======== CONFIG PDF ========
PDF_CONFIG = pdfkit.configuration(wkhtmltopdf=r"C:\Users\ASUS\wkhtmltopdf\bin\wkhtmltopdf.exe")

# ===========================================
# LOGIN HR
# ===========================================
@eel.expose
def login_hr(username, password):
    hashed = hashlib.sha256(password.encode()).hexdigest()
    hr = db.fetch_one("SELECT * FROM hr WHERE username=%s AND password=%s", (username, hashed))
    return bool(hr)

# ===========================================
# LOGIN KARYAWAN
# ===========================================
@eel.expose
def login_karyawan(username, password):
    hashed = hashlib.sha256(password.encode()).hexdigest()
    user = db.fetch_one(
        "SELECT * FROM karyawan WHERE username=%s AND password=%s AND status_validasi=1",
        (username, hashed)
    )
    return bool(user)

# ===========================================
# REGISTRASI KARYAWAN
# ===========================================
@eel.expose
def registrasi_karyawan(nama, no_hp, alamat, id_jabatan, tanggal_masuk, username, password):
    hashed = hashlib.sha256(password.encode()).hexdigest()
    try:
        db.execute(
            "INSERT INTO karyawan (nama_lengkap, no_hp, alamat, id_jabatan, tanggal_masuk, username, password) VALUES (%s,%s,%s,%s,%s,%s,%s)",
            (nama, no_hp, alamat, id_jabatan, tanggal_masuk, username, hashed)
        )
        return True
    except Exception as e:
        print("Error registrasi:", e)
        return False
    

@eel.expose
def get_total_karyawan():
    result = db.fetch_one("SELECT COUNT(*) AS total FROM karyawan")
    return result['total'] if result else 0

@eel.expose
def get_total_jabatan():
    result = db.fetch_one("SELECT COUNT(*) AS total FROM jabatan")
    return result['total'] if result else 0

@eel.expose
def get_total_slip():
    # Slip gaji bulan ini
    import datetime
    now = datetime.datetime.now()
    month = now.month
    year = now.year
    result = db.fetch_one(
        "SELECT COUNT(*) AS total FROM slip_gaji WHERE MONTH(tanggal)=%s AND YEAR(tanggal)=%s",
        (month, year)
    )
    return result['total'] if result else 0

@eel.expose
def get_aktivitas_terbaru():
    # Contoh: karyawan baru, slip terbaru, jabatan baru, payroll baru
    activities = []
    # 5 karyawan baru menunggu validasi
    karyawan_baru = db.fetch_one("SELECT COUNT(*) AS total FROM karyawan WHERE is_validated=0")
    activities.append(f"{karyawan_baru['total']} Karyawan baru menunggu validasi akun")

    # 2 Slip terbaru
    slip_terbaru = db.fetch("SELECT tanggal FROM slip_gaji ORDER BY tanggal DESC LIMIT 2")
    for s in slip_terbaru:
        activities.append(f"Slip Gaji berhasil dibuat tanggal {s['tanggal']}")

    # 1 jabatan terbaru
    jabatan_terbaru = db.fetch_one("SELECT nama_jabatan FROM jabatan ORDER BY id DESC LIMIT 1")
    if jabatan_terbaru:
        activities.append(f"Jabatan “{jabatan_terbaru['nama_jabatan']}” ditambahkan")

    # Penggajian terakhir
    payroll_last = db.fetch_one("SELECT tanggal FROM penggajian ORDER BY tanggal DESC LIMIT 1")
    if payroll_last:
        activities.append(f"Penggajian periode {payroll_last['tanggal']} telah diproses")

    return activities


# ===========================================
# KELOLA JABATAN (VERSI BARU FIXED)
# ===========================================
@eel.expose
def tambah_jabatan(nama, gaji, tunjangan):
    try:
        db.execute(
            "INSERT INTO jabatan (nama_jabatan, gaji_pokok, tunjangan) VALUES (%s,%s,%s)",
            (nama, gaji, tunjangan)
        )
        return True
    except Exception as e:
        print("Error tambah jabatan:", e)
        return False


@eel.expose
def get_all_jabatan():
    try:
        data = db.fetch_all("SELECT * FROM jabatan ORDER BY id ASC")
        return data
    except Exception as e:
        print("Error get_all_jabatan:", e)
        return []

@eel.expose
def update_jabatan(id, nama, gaji, tunjangan):
    try:
        db.execute(
            "UPDATE jabatan SET nama_jabatan=%s, gaji_pokok=%s, tunjangan=%s WHERE id=%s",
            (nama, gaji, tunjangan, id)
        )
        return True
    except Exception as e:
        print("Error update jabatan:", e)
        return False


@eel.expose
def delete_jabatan(id):
    try:
        db.execute("DELETE FROM jabatan WHERE id=%s", (id,))
        return True
    except Exception as e:
        print("Error delete jabatan:", e)
        return False



# ===========================================
# KELOLA KARYAWAN
# ===========================================
@eel.expose
def tambah_karyawan(nama, nohp, alamat, id_jabatan, tgl, username, password):
    hashed = hashlib.sha256(password.encode()).hexdigest()
    db.execute(
        "INSERT INTO karyawan (nama_lengkap, no_hp, alamat, id_jabatan, tanggal_masuk, username, password) VALUES (%s,%s,%s,%s,%s,%s,%s)",
        (nama, nohp, alamat, id_jabatan, tgl, username, hashed)
    )

@eel.expose
def get_all_karyawan():
    query = """
        SELECT 
            k.id,
            k.nama_lengkap,
            k.no_hp,
            k.alamat,
            k.username,
            DATE_FORMAT(k.tanggal_masuk, '%Y-%m-%d') AS tanggal_masuk,
            k.id_jabatan,
            j.nama_jabatan
        FROM karyawan k
        LEFT JOIN jabatan j ON k.id_jabatan = j.id
        ORDER BY k.id DESC
    """
    return db.fetch_all(query)
 # ✔ Pakai db global

# ===========================================
# EDIT KARYAWAN
# ===========================================
@eel.expose
def edit_karyawan(id, nama, nohp, alamat, id_jabatan, tanggal_masuk, username, password):
    try:
        id = int(id)
        id_jabatan = int(id_jabatan)
        if password and password.strip() != "":
            hashed = hashlib.sha256(password.encode()).hexdigest()
            db.execute("""
                UPDATE karyawan 
                SET nama_lengkap=%s, no_hp=%s, alamat=%s, id_jabatan=%s, 
                    tanggal_masuk=%s, username=%s, password=%s 
                WHERE id=%s
            """, (nama, nohp, alamat, id_jabatan, tanggal_masuk, username, hashed, id))
        else:
            db.execute("""
                UPDATE karyawan 
                SET nama_lengkap=%s, no_hp=%s, alamat=%s, id_jabatan=%s, 
                    tanggal_masuk=%s, username=%s
                WHERE id=%s
            """, (nama, nohp, alamat, id_jabatan, tanggal_masuk, username, id))
        return True
    except Exception as e:
        print("ERROR edit_karyawan:", e)
        return False
# ===========================================
# HAPUS KARYAWAN
# ===========================================
@eel.expose
def hapus_karyawan(id):
    db.execute("DELETE FROM karyawan WHERE id=%s", (id,))


# ===========================================
# VALIDASI AKUN KARYAWAN
# ===========================================
@eel.expose
def get_karyawan_belum_validasi():
    return db.fetch_all("SELECT id, nama_lengkap, username FROM karyawan WHERE status_validasi=0")

@eel.expose
def validasi_karyawan(id):
    db.execute("UPDATE karyawan SET status_validasi=1 WHERE id=%s", (id,))

# ===========================================
# PROSES PAYROLL
# ===========================================
@eel.expose
def get_payroll_by_periode(periode):
    try:
        # Ambil semua karyawan dan total gajinya
        data = db.fetch_all("""
            SELECT 
                k.id,
                k.nama_lengkap,
                j.nama_jabatan,
                (j.gaji_pokok + j.tunjangan) AS total_gaji
            FROM karyawan k
            LEFT JOIN jabatan j ON k.id_jabatan = j.id
        """)

        # Simpan ke tabel payroll jika periode belum ada
        for d in data:
            db.execute("""
                INSERT IGNORE INTO payroll (id_karyawan, periode, total_gaji)
                VALUES (%s, %s, %s)
            """, (d["id"], periode, d["total_gaji"]))

        # Kembalikan data payroll periode tsb
        return db.fetch_all("""
            SELECT 
                k.id,
                k.nama_lengkap,
                j.nama_jabatan,
                (j.gaji_pokok + j.tunjangan) AS total_gaji
            FROM payroll p
            JOIN karyawan k ON p.id_karyawan = k.id
            LEFT JOIN jabatan j ON k.id_jabatan = j.id
            WHERE p.periode = %s
        """, (periode,))

    except Exception as e:
        print("ERROR get_payroll_by_periode:", e)
        return []

@eel.expose
def generate_payroll_pdf(periode):
    data = get_payroll_by_periode(periode)

    # Buat nama file PDF
    filename = f"slip_{periode}.pdf"
    filepath = f"web/slip_gaji/{filename}"

    # ===== IMPORT LIBRARY =====
    from reportlab.lib.pagesizes import A4
    from reportlab.pdfgen import canvas
    from reportlab.platypus import Table, TableStyle, Paragraph
    from reportlab.lib import colors
    from reportlab.lib.styles import getSampleStyleSheet
    from reportlab.lib.units import cm

    # ===== INISIALISASI PDF =====
    pdf = canvas.Canvas(filepath, pagesize=A4)
    width, height = A4

    # ===== HEADER =====
    pdf.setFont("Helvetica-Bold", 16)
    pdf.drawString(50, 800, "SMARTPAYROLL INDONESIA")

    pdf.setFont("Helvetica", 10)
    pdf.drawString(50, 785, "Alamat: Jl. Teknologi No. 12, Medan")
    pdf.drawString(50, 770, "Telp: (061) 1234567")

    pdf.setFont("Helvetica-Bold", 14)
    pdf.drawString(50, 740, f"Slip Gaji Periode: {periode}")

    pdf.line(50, 735, width-50, 735)

    # ===== STYLING UNTUK TABEL =====
    styles = getSampleStyleSheet()
    styleN = styles["Normal"]

    table_data = [
        ["Nama Karyawan", "Jabatan", "Total Gaji"]
    ]

    # Isi tabel dengan data karyawan, gunakan Paragraph untuk wrap text jabatan
    for k in data:
        table_data.append([
            k["nama_lengkap"],
            Paragraph(k["nama_jabatan"], styleN),  # Teks jabatan otomatis wrap
            f"Rp {k['total_gaji']:,}"
        ])

    # Buat tabel dengan kolom berukuran proporsional
    col_widths = [7*cm, 6*cm, 4*cm]
    table = Table(table_data, colWidths=col_widths)

    table.setStyle(TableStyle([
        ("BACKGROUND", (0,0), (-1,0), colors.lightblue),
        ("TEXTCOLOR", (0,0), (-1,0), colors.white),
        ("ALIGN", (0, 0), (-1, -1), "LEFT"),
        ("FONTNAME", (0,0), (-1,0), "Helvetica-Bold"),
        ("FONTSIZE", (0,0), (-1,-1), 10),
        ("BOTTOMPADDING", (0,0), (-1,0), 10),
        ("BACKGROUND", (0,1), (-1,-1), colors.whitesmoke),
        ("GRID", (0,0), (-1,-1), 0.5, colors.grey),
    ]))

    # Hitung posisi Y agar tabel tidak keluar halaman
    y_position = 650
    table.wrapOn(pdf, 50, y_position)
    table_height = 20 * len(table_data)  # perkiraan tinggi tabel
    table.drawOn(pdf, 50, y_position - table_height)

    # ===== FOOTER =====
    pdf.setFont("Helvetica-Oblique", 8)
    pdf.drawString(50, 50, f"Dicetak pada: {datetime.datetime.now().strftime('%d-%m-%Y %H:%M:%S')}")

    # Simpan PDF
    pdf.save()

    # ===== SIMPAN KE DATABASE =====
    db = DB()
    for k in data:
        db.execute("""
            INSERT INTO payroll_slip (id_karyawan, periode, total_gaji, filename, tanggal_generate)
            VALUES (%s, %s, %s, %s, NOW())
        """, (k["id"], periode, k["total_gaji"], filename))

    return filename


@eel.expose
def get_slip_list():
    db = DB()
    query = """
    SELECT 
        ps.id_slip,
        k.nama_lengkap,
        ps.periode,
        ps.total_gaji,
        ps.filename,
        DATE_FORMAT(ps.tanggal_generate, '%Y-%m-%d') AS tanggal_generate
    FROM payroll_slip ps
    JOIN karyawan k ON ps.id_karyawan = k.id
    ORDER BY ps.id_slip DESC
"""
    return db.fetch_all(query)



# ===========================================
# DASHBOARD KARYAWAN
# ===========================================

@eel.expose
def get_karyawan_dashboard(username):
    query = """
        SELECT 
            k.nama_lengkap,
            j.nama_jabatan,
            (j.gaji_pokok + j.tunjangan) AS total_gaji,
            DATE_FORMAT(k.tanggal_masuk, '%Y-%m-%d') AS tanggal_masuk
        FROM karyawan k
        LEFT JOIN jabatan j ON k.id_jabatan = j.id
        WHERE k.username=%s
    """
    return db.fetch_one(query, (username,))



@eel.expose
def get_slip_by_karyawan(username):
    """
    Mengambil daftar slip gaji milik karyawan berdasarkan username
    """
    query = """
        SELECT 
            ps.id_slip,
            ps.periode,
            ps.total_gaji,
            ps.filename,
            DATE_FORMAT(ps.tanggal_generate, '%%Y-%%m-%d') AS tanggal_generate
        FROM payroll_slip ps
        JOIN karyawan k ON ps.id_karyawan = k.id
        WHERE k.username=%s
        ORDER BY ps.periode DESC
    """
    return db.fetch_all(query, (username,))


# ===========================================
# START EEL
# ===========================================
eel.start('login.html', size=(900, 600))
