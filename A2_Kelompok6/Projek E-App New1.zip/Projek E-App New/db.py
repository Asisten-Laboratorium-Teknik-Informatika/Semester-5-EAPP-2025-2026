import mysql.connector

class DB:
    def __init__(self):
        self.conn = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",
            database="gaji_karyawan"
        )
        self.cursor = self.conn.cursor(dictionary=True)

    def fetch_one(self, query, params=()):
        self.cursor.execute(query, params)
        return self.cursor.fetchone()

    def fetch_all(self, query, params=()):
        self.cursor.execute(query, params)
        return self.cursor.fetchall()

    def execute(self, query, params=None):
        self.cursor.execute(query, params)
        self.conn.commit()
        return True
